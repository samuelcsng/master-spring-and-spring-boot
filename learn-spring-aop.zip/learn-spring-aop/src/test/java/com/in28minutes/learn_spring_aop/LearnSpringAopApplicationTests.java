package com.in28minutes.learn_spring_aop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnSpringAopApplicationTests {

	@Test
	void contextLoads() {
	}

}
